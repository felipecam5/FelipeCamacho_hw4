#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){

static const int MAX_FILE_ROWS = 300;

float* RADIO = malloc(MAX_FILE_ROWS*sizeof(float));
float* VELOCIDAD = malloc(MAX_FILE_ROWS*sizeof(float));
float* MODELONUEVO = malloc(MAX_FILE_ROWS*sizeof(float));
float* RESTANUEVO = malloc(MAX_FILE_ROWS*sizeof(float));
float* SUMATORIA = malloc(MAX_FILE_ROWS*sizeof(float));
float* MODELOVIEJO = malloc(MAX_FILE_ROWS*sizeof(float));
float* RESTAVIEJO = malloc(MAX_FILE_ROWS*sizeof(float));
float pi=3.1416;

float chicuadradoNUEVO;
float chicuadradoVIEJO;



double lines[MAX_FILE_ROWS][2];
FILE *file = fopen("RadialVelocities.dat", "r");

for (int i = 0; i < MAX_FILE_ROWS; i++)
{
    if (feof(file))
        break;

    fscanf(file, "%lf %lf ", &(lines[i][0]), &(lines[i][1]));
   //printf("%f %f \n",(lines[i][0]), (lines[i][1]));
	VELOCIDAD[i]=(lines[i][1]);
	RADIO[i]=(lines[i][0]);
	//printf("%f \n",VELOCIDAD[i]);
	
}

fclose(file);

float AL1nuevo;
float AL2nuevo;
float AL3nuevo;
float AL1viejo;
float AL2viejo;
float AL3viejo;
int contador=0;
float Bb=0.2497;
float Bd=5.16;
float Ad=0.3105;
float Ah=64.3;
float V;
float alfa;
float beta;
float Mb;
float Md;
float R;
float Mh;
float XVIEJO;
float XNUEVO;
float fvieja;
float fnueva;
float betha;
float SUMANUEVO;
float ALMODELONUEVO;
float SUMAVIEJO;
float ALMODELOVIEJO;
float Vel(float Mb,float Md,float Mh,float R)

{
	V= V = ((pow(Mb,0.5))*(R)/pow((pow(R,2)+pow(Bb,2)),0.75)) + ((pow(Md,0.5))*(R)/ pow((pow(R,2)+pow(Bd+Ad,2)),0.75)) + ((pow(Mh,0.5))/pow((pow(R,2)+pow(Ah,2)),0.25));
	return V;
	
}





int i;
int j;
for(j=0;j<1000;j++)
{
AL1nuevo = drand48();
AL2nuevo = drand48();
AL3nuevo = drand48();
if(i>=1)
{
for(j=0;j<300;j++)
{
MODELONUEVO[j]= Vel(AL1nuevo,AL2nuevo,AL3nuevo,RADIO[j]);
MODELOVIEJO[j]= Vel(AL1nuevo,AL2nuevo,AL3nuevo,RADIO[j]);
}

for(j=0;j<300;j++)
{
ALMODELONUEVO = VELOCIDAD[j]-MODELONUEVO[j];
RESTANUEVO[j] = ALMODELOVIEJO;
ALMODELOVIEJO = VELOCIDAD[j]-MODELONUEVO[j];
RESTAVIEJO[j] = ALMODELOVIEJO;


}

for(j=0;j<300;j++)
{


SUMANUEVO = SUMANUEVO + RESTANUEVO[j];
SUMAVIEJO = SUMAVIEJO + RESTAVIEJO[j];

}
chicuadradoNUEVO=exp(-(1.0/2.0)*pow(SUMANUEVO,2));
chicuadradoVIEJO=exp(-(1.0/2.0)*pow(SUMAVIEJO,2));

alfa=chicuadradoNUEVO/chicuadradoVIEJO;

if(alfa>1)
{
AL1viejo=AL1nuevo;
AL2viejo=AL2nuevo;
AL3viejo=AL3nuevo;
}
if(alfa<1)
{
	
	beta= drand48();
	if(betha<alfa)
	{
	AL1viejo=AL1nuevo;
	AL2viejo=AL2nuevo;
	AL3viejo=AL3nuevo;
	
	}
	if(alfa<beta)
	{
	AL1viejo=AL1viejo;
	AL2viejo=AL2viejo;
	AL3viejo=AL3viejo;
		
	}

}

}
if(i==0)
{
AL1viejo = AL1nuevo;
AL2viejo = AL2nuevo;
AL3viejo = AL3nuevo;
}


 }

printf("%f \n ",AL1viejo);
printf("%f \n",AL2viejo);
printf("%f \n",AL3viejo);






FILE* Archivo1 = fopen("Resultados.txt","w");
fprintf(Archivo1,"%f ",AL1viejo);
fprintf(Archivo1,"%f ",AL2viejo);
fprintf(Archivo1,"%f ",AL3viejo);

return 0;

}


